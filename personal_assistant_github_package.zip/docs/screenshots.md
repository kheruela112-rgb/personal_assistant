Mock screenshots: Home icon, Main chat UI, Settings modal, Test connection success.
(They're illustrative; open the app to see the real UI.)
