PERSONAL ASSISTANT - GitHub Auto-Build Package
---------------------------------------------
1. Create a new GitHub repository (use the GitHub mobile site or app).
2. Upload the contents of this folder to the repo (you can upload the zip directly).
3. After uploading, GitHub Actions will trigger the build workflow on push.
4. Wait a few minutes, then open the "Actions" tab to watch the build, or open "Releases" to download the APK when available.
5. Install the downloaded APK on your Android phone (allow unknown sources if needed).
